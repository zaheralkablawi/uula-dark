@echo off
chcp 65001 >nul
title UULA Dark - Install
echo.
echo  UULA Dark - PowerPoint add-in
echo  ------------------------------
set "DEST=%LOCALAPPDATA%\UULA\UULA Dark"
if not exist "%DEST%" mkdir "%DEST%"
copy /Y "%~dp0manifest.xml" "%DEST%\manifest.xml" >nul
if errorlevel 1 (
  echo  [X] Could not copy manifest.xml
  pause
  exit /b 1
)
reg add "HKCU\Software\Microsoft\Office\16.0\WEF\Developer" /v "3787f387-47db-49c6-8a0a-f3c367f0dca8" /t REG_SZ /d "%DEST%\manifest.xml" /f >nul
if errorlevel 1 (
  echo  [X] Could not register the add-in
  pause
  exit /b 1
)
echo  [OK] Installed.
echo.
echo  Close PowerPoint completely, then open it again.
echo  You will find "UULA Dark" on the Home tab.
echo.
echo  تم التثبيت. أغلق PowerPoint تماما ثم افتحه، وستجد UULA Dark في تبويب الصفحة الرئيسية.
echo.
pause
