@echo off
chcp 65001 >nul
title UULA Dark - Uninstall
reg delete "HKCU\Software\Microsoft\Office\16.0\WEF\Developer" /v "3787f387-47db-49c6-8a0a-f3c367f0dca8" /f >nul 2>&1
if exist "%LOCALAPPDATA%\UULA\UULA Dark\manifest.xml" del /Q "%LOCALAPPDATA%\UULA\UULA Dark\manifest.xml"
echo  [OK] UULA Dark removed. Restart PowerPoint.
echo  تمت إزالة UULA Dark. أعد تشغيل PowerPoint.
pause
