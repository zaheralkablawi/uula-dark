﻿UULA Dark — تثبيت على Windows
================================

التثبيت:
1. فك ضغط هذا الملف في أي مكان (مثل سطح المكتب).
2. اضغط مرتين على install.bat
3. أغلق PowerPoint تماما ثم افتحه.
4. ستجد زر UULA Dark في تبويب الصفحة الرئيسية (Home).

إذا ظهرت رسالة Windows protected your PC:
اضغط More info ثم Run anyway.

الإزالة: اضغط مرتين على uninstall.bat ثم أعد تشغيل PowerPoint.

المتطلبات:
- Microsoft 365 (PowerPoint محدّث).
- اتصال بالإنترنت (الأداة تُفتح من GitHub وتتحدث تلقائيا).
- خط UULA Sans و UULA Sans Medium مثبتان على الجهاز.

------------------------------------------------
Install: unzip, double-click install.bat, restart PowerPoint.
Uninstall: double-click uninstall.bat.
Requires Microsoft 365 and an internet connection.

By Zaher Alkablawi
